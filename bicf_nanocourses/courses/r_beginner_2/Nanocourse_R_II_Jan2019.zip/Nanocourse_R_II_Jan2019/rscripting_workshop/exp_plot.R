## example R script: exp_plot.R
## On the command-line: Rscript exp_plot.R 2 10


args<-commandArgs(TRUE)   # Get variables from command line
num1 <- as.numeric(args[1])
num2 <- as.numeric(args[2])

square <- function(x,n=c(1:num2)) { x^n }

x <- c(1:num2)
y <- square(num1)

postscript(file="exp_plot.ps", paper="letter", horizontal=TRUE)
plot(x, y, ylab=paste(num1,"^x",sep=""))
dev.off()