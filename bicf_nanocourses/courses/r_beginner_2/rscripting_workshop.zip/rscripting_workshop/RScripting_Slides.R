## 2018 Nanocourse - R Scripting

getwd()
setwd("~/rscripting")
datadir <- getwd()
list.files(datadir)

? read.table

list.files(datadir)
tbl <- read.table(file="mtcars.csv", sep=',', header=T)
head(tbl)

tbl <- read.table(file="mtcars.csv", sep=',', header=T, row.names=1)
head(tbl)

rownames(tbl)
colnames(tbl)

? rnorm
? rep
mpg = c(23, 34.9, 28, 32.5)
cyl = rep(1:2, 2)
drat = rnorm(4, mean=3.5)
df = data.frame(mpg, cyl, drat)
head(df)

x <- rnorm(1)
if (x>0){
  y <- x + 1
}
x
y

x <- rnorm(1)
if (x>0){
  y <- x + 1
} else {
  y <- x - 1
}
x
y

names(tbl)
Ys <- names(tbl)[3:6]
x <- tbl$mpg
par(mfrow=c(2,2))
for (i in 1:4) {
  y <- tbl[,Ys[i]]
  plot(x,y,xlab="mpg", ylab=Ys[i])
}

names(tbl)
Xs <- names(tbl)[3:4]
Ys <- names(tbl)[5:6]
par(mfrow=c(2,2))
for (i in 1:2){
  x <- tbl[,Xs[i]]
  for (j in 1:2) {
    y <- tbl[,Ys[j]]
    plot(x, y, xlab=Xs[i], ylab=Ys[j])
  }
}

i <- 0
square <- 0
while (square < 88) {
  i <- i + 1
  square <- i^2
  cat("i=", i, "; square=", square,"; square<88 is", (square < 88), '\n')
}
i - 1

i <- 0
j <- 0
repeat {
  if (j > 14) { break }
  i <- i+1; j <- j + 1; 
  if(i == 4) {next}
  j <- j + 1; 
  cat("i=", i, "; j=", j, '\n');
} 
i
j


? aggregate

aggregate(mpg ~ cyl, tbl, summary)
par(mfrow=c(1,1))
boxplot(tbl$mpg ~ tbl$cyl, xlab="cyl", ylab="mpg")

table(tbl$cyl)
for (i in c(4,6,8)) {
  cat("mpg mean (when cyl=", i, "): ", mean(tbl$mpg[tbl$cyl==i]), '\n')
}


by(tbl, tbl$cyl, colMeans)

replicate(12, sample(1:50, 4))

my.fun.1 <- function(x, y, n) {
  return(x+y^n)
}
my.fun.1(1,2,1)
my.fun.1(2,3,2)

my.fun.1 <- function(x, y, n=2) {
  return(x+y^n)
}
my.fun.1(1,2)
my.fun.1(2,3,1)


my.fun.2 <- function(x, y) {
  return(my.fun.1(x,y,1) + my.fun.1(x,y))
}
my.fun.2(1,2)
my.fun.2(2,3)
(1+2^1) + (1+2^2)
(2+3^1) + (2+3^2)

my.fun <- function(x, y) {
  z <- my.fun.1(x,y,1) + my.fun.1(x,y)
  return(list(value=z, vector=rep(z,z)))
}
my.fun(1,2)
my.fun(2,3)

mapply(rep, times = 1:4, x = 4:1)

choose.col <- function(cyl){
  if(cyl==4){col <- "red"}
  if(cyl==6){col <- "green"}
  if(cyl==8){col <- "blue"}
  return(col)
}
pch.col <- sapply(tbl$cyl, choose.col)
cbind(tbl$cyl,pch.col)[1:5,]

plot(tbl$mpg, tbl$hp, col=sapply(tbl$cyl, choose.col) )
legend("topright", legend=c(4,6,8), col=c("red","green","blue"), pch=1)



