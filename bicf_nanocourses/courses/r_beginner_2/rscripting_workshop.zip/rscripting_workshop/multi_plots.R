MultiPlots <- function(data, mapping, title) {
    library(ggplot2)
    library(grid)
    library(gridExtra)
    p1 = ggplot(data = data, mapping) + geom_boxplot()
    p2 = ggplot(data = data, mapping) +  geom_violin() + geom_jitter(height = 0)
    grid.arrange(p1, p2, ncol=2, top = title)
}
