## example R script: example_script.R

choose.col <- function(cyl){
  if(cyl==4){col <- "red"}
  if(cyl==6){col <- "green"}
  if(cyl==8){col <- "blue"}
  return(col)
}

tbl <- read.table(file="mtcars.csv", sep=',', header=T, row.names=1)

postscript(file="cool_plot.ps", paper="letter", horizontal=TRUE)
plot(tbl$mpg, tbl$hp, col=sapply(tbl$cyl, choose.col) )
legend("topright", legend=c(4,6,8), col=c("red","green","blue"), pch=1)
dev.off()

mpg.cyl <- aggregate(mpg ~ cyl, tbl, summary)
write.csv(mpg.cyl, file="mpg_summary_cyl.csv", row.names=F)

png(filename = "mpg_by_cyl.png", width = 480, height = 480)
boxplot(tbl$mpg ~ tbl$cyl, xlab="cyl", ylab="mpg")
dev.off()