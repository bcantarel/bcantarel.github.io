#workshop

mock <-read.table(file="mock_community.txt",sep='\t',header=TRUE)

#1
x <- filter(mock, taxlevel == 6)
mock1 <- x[order(x$Mock1, decreasing = T),][1,]
mock2 <- x[order(x$Mock2, decreasing = T),][1,]
mock3 <- x[order(x$Mock3, decreasing = T),][1,]
mock4 <- x[order(x$Mock4, decreasing = T),][1,]

#2
x <- filter(mock, taxlevel == 2)
x <- mutate(x, TotalAbund = rowSums(x[,3:6]))
x <- x[order(x$TotalAbund, decreasing = TRUE),][1,c(2,7)]

#3
x <- filter(mock, taxlevel ==2)
x <- mutate(x, phylaMeans = rowMeans(x,[,3:6]))