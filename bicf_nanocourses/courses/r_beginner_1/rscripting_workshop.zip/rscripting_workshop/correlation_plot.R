#!/usr/bin/env Rscript
suppressPackageStartupMessages(library("argparse"))
suppressPackageStartupMessages(library("corrplot"))

# Create parser object
parser <- ArgumentParser()

# Specify our desired options
# By default ArgumentParser will add an help option
parser$add_argument("-f", "--file",
    help = "File paths to csv data file", required = TRUE)
parser$add_argument("-o", "--out",
    help = "The output file name", required = TRUE)


# Get command line options, if help option encountered print help and exit,
# Otherwise if options not found on command line then set defaults,
args <- parser$parse_args()

# Read in CSV file
csv.file <- read.table(file=args$file, sep=",", header=T, row.names=1)

# Make a correlation matrix
csv.corr <- cor(csv.file)

pdf(paste0(args$out, ".pdf"),  width=4, height=4)
corrplot(csv.corr, method="shade", shade.col=NA, tl.col="black", tl.srt=45)
dev.off()
