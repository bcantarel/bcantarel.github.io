#!/usr/bin/env Rscript
suppressPackageStartupMessages(library("argparse"))

# Create parser object
parser <- ArgumentParser()

# Specify our desired options
# By default ArgumentParser will add an help option
parser$add_argument("-f", "--file",
    help = "File paths to csv data file", required = TRUE)
parser$add_argument("-x",
    help = "The first variable", required = TRUE)
parser$add_argument("-y",
    help = "The second variable", required = TRUE)


# Get command line options, if help option encountered print help and exit,
# Otherwise if options not found on command line then set defaults,
args <- parser$parse_args()

# Read in CSV file
csv.file <- read.table(file=args$file, sep=",", header=T)

# Store the two variables
variable.x <- unlist(csv.file[args$x])
variable.y <- unlist(csv.file[args$y])

# Calculate the wilcox rank sum test
pearson <- cor.test(variable.x, variable.y)

# Print out correlation to file
print(pearson)
